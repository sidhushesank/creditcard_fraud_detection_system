import joblib
from sklearn.ensemble import VotingClassifier
from sklearn.preprocessing import StandardScaler
# Assuming you have already trained your model and scaler

# Example model and scaler (replace with your actual trained model and scaler)
# You can skip the training part if you've already trained the model
# Here is just an example setup for illustration

# Create a dummy VotingClassifier and StandardScaler
# (use your own trained model and scaler)
voting_clf = VotingClassifier(estimators=[('lr', None), ('rf', None), ('gb', None)], voting='hard')
scaler = StandardScaler()

# Save the Voting Classifier model to the 'models' directory
joblib.dump(voting_clf, 'voting_classifier.pkl')  # Save the Voting Classifier model

# Save the StandardScaler object to the 'models' directory
joblib.dump(scaler, 'scaler.pkl')  # Save the scaler for future use (in your Flask app)
