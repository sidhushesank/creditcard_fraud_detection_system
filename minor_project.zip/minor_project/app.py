import joblib
import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)

# Load the trained models and scaler
voting_clf = joblib.load('models/voting_classifier.pkl')
scaler = joblib.load('models/scaler.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get form data (transaction details entered by the user)
        amount_spent = float(request.form['Amount Spent'])
        card_limit = float(request.form['Card Limit'])
        amount_left = float(request.form['Amount Left'])
        time_spent = float(request.form['Time Spent'])
        time_of_amount_spent = float(request.form['Time of Amount Spent'])

        # Prepare the input data in the format the model expects
        new_transaction = pd.DataFrame([[amount_spent, card_limit, amount_left, time_spent, time_of_amount_spent]], 
                                       columns=['Amount Spent', 'Card Limit', 'Amount Left', 'Time Spent', 'Time of Amount Spent'])

        # Standardize the input data using the same scaler used during training
        new_transaction_scaled = scaler.transform(new_transaction)

        # Predict fraud status (1 for fraud, 0 for legitimate)
        prediction = voting_clf.predict(new_transaction_scaled)

        # Display the result
        if prediction == 1:
            result = "The transaction is fraudulent!"
        else:
            result = "The transaction is legitimate."

        return render_template('result.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
