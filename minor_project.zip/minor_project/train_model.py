import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
import joblib

# Load the dataset
file_path = "data/credit_card_transactions_updated.csv"  # Update with your path
df = pd.read_csv(file_path)

# Refined logic for fraud detection
df['Fraud'] = ((df['Amount Spent'] > 0.5 * df['Card Limit']) & 
               (df['Amount Spent'] > df['Amount Left'])).astype(int)

# Preprocess the dataset
X = df.drop(columns=["Transaction ID", "Cardholder Name", "Transaction Time", 
                     "Time of Amount Spent", "Fraud"])  # Remove 'Fraud' from features
y = df["Fraud"]  # 'Fraud' is the target variable

# Train-test split (Stratify to ensure balanced classes for fraud detection)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Standardize features to improve model performance
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Initialize models
log_reg = LogisticRegression(max_iter=1000)
random_forest = RandomForestClassifier(n_estimators=100, random_state=42)
gradient_boost = GradientBoostingClassifier(n_estimators=100, random_state=42)

# Train the models
voting_clf = VotingClassifier(estimators=[ 
    ('log_reg', log_reg), 
    ('random_forest', random_forest), 
    ('gradient_boost', gradient_boost)
], voting='hard')

# Train the ensemble model
voting_clf.fit(X_train, y_train)

# Save the trained model and scaler
joblib.dump(voting_clf, 'models/voting_classifier.pkl')  # Save Voting Classifier
joblib.dump(scaler, 'models/scaler.pkl')  # Save scaler for future use

print("Model and Scaler saved successfully!")
